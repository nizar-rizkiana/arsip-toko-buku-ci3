-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 29, 2023 at 09:15 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_buku_ci3`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_buku`
--

CREATE TABLE `tb_buku` (
  `id_buku` int(100) NOT NULL,
  `id_kategori` int(100) DEFAULT NULL,
  `judul` varchar(50) NOT NULL,
  `harga` int(200) NOT NULL,
  `penerbit` varchar(30) NOT NULL,
  `pengarang` varchar(30) NOT NULL,
  `tahun` int(20) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `gambar` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_buku`
--

INSERT INTO `tb_buku` (`id_buku`, `id_kategori`, `judul`, `harga`, `penerbit`, `pengarang`, `tahun`, `deskripsi`, `gambar`) VALUES
(2, 3, 'Si Juki', 50000, 'Gramedia', 'danang', 2019, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur sit vero qui modi eum pariatur sunt nam. Dolorum, pariatur, cumque beatae repudiandae quos autem reprehenderit voluptate laborum placeat similique odio error veritatis repellendus ipsa. Doloribus quae odio expedita iure aliquam, dolore temporibus quas numquam ipsam consequatur vitae velit nihil nesciunt.', 'juki.jpg'),
(3, 4, 'Dilan 1990', 90000, 'Grame', 'Sutarya', 2015, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa ut, nesciunt aspernatur consectetur dolorem corporis omnis architecto optio error possimus mollitia reprehenderit eligendi itaque corrupti repellat atque vitae, qui hic repellendus. Cumque, fuga. Quo, fugit, ab. Iste accusamus, nulla quasi eveniet itaque iusto qui ratione vel! Animi iste voluptates labore.\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Culpa ut, nesciunt aspernatur consectetur dolorem corporis omnis architecto optio error possimus mollitia reprehenderit eligendi itaque corrupti repellat atque vitae, qui hic repellendus. Cumque, fuga. Quo, fugit, ab. Iste accusamus, nulla quasi eveniet itaque iusto qui ratione vel! Animi iste voluptates labore.', 'novel-dilan.jpeg'),
(4, 5, 'Baru Klinting', 70000, 'Kompas', 'Sunandar', 2012, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa ut, nesciunt aspernatur consectetur dolorem corporis omnis architecto optio error possimus mollitia reprehenderit eligendi itaque corrupti repellat atque vitae, qui hic repellendus. Cumque, fuga. Quo, fugit, ab. Iste accusamus, nulla quasi eveniet itaque iusto qui ratione vel! Animi iste voluptates labore.', 'baru-klinting.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id` int(100) NOT NULL,
  `nama_kategori` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id`, `nama_kategori`) VALUES
(3, 'Komik'),
(4, 'Novel'),
(5, 'Legenda'),
(6, 'Drama');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` int(11) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `email`) VALUES
(1, 'admin', 1234, 'admin@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_buku`
--
ALTER TABLE `tb_buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_buku`
--
ALTER TABLE `tb_buku`
  MODIFY `id_buku` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
