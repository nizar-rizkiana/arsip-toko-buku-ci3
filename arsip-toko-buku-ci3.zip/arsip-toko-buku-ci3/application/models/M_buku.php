<?php


class M_buku extends CI_Model{
	
	public function tampil_data()
    {
        $this->db->select('*');
        $this->db->from('tb_buku');
        $this->db->join('tb_kategori', 'tb_kategori.id = tb_buku.id_kategori', 'left');
        $query = $this->db->get();
        return $query;

    }
    public function detail_data($where,$table)
    {
        $this->db->select('*');
        $this->db->from('tb_buku');
        $this->db->where('id_buku', $where);
        $this->db->join('tb_kategori', 'tb_kategori.id = tb_buku.id_kategori', 'left');
        $query = $this->db->get();
        return $query;
    }
    public function input_data($data, $table){
        $this->db->insert($table, $data);        
    }

    public function hapus_data($where, $table){
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function edit_data($where,$table){
       $this->db->select('*');
        $this->db->from('tb_buku');
        $this->db->where('id_buku', $where);
        $this->db->join('tb_kategori', 'tb_kategori.id = tb_buku.id_kategori', 'left');
        $query = $this->db->get();
        return $query;
    }
    public function update_data($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }
    public function total()
    {
        return $this->db->count_all_results('tb_buku');
    }
}
