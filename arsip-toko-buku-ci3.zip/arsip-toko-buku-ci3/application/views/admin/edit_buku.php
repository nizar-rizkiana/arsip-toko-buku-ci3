<div class="body flex-grow-1 px-3">
	<div class="container-lg">
		<?php foreach($buku as $b) : ?>
		<form action="<?= base_url() ?>buku/update" method="post" enctype="multipart/form-data">
			<input type="hidden" id="id" name="id" value="<?= $b->id_buku ?>">
			<input type="hidden" id="gambaLama" name="gambarLama" value="<?= $b->gambar ?>">
			<div class="card">
	          <div class="row g-0">
	            <div class="col-md-4">
	            	<img class="card-img" src="<?= base_url() ?>uploads/<?= $b->gambar ?>" alt="gambar buku" style="max-height: 500px;">
	            	<input type="file" class="form-control mt-4" name="gambar">
	            </div>
	            <div class="col-md-8">
	              <div class="card-body">
	                <div class="mb-3 row">
	                    <label class="col-sm-4 col-form-label" for="judul">Judul Buku</label>
	                    <div class="col-sm-8">
	                        <input class="form-control" id="judul" type="text" placeholder="Masukkan judul buku" name="judul" required value="<?= $b->judul ?>">
	                    </div>
	                </div>
	                <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label" for="kategori">Kategori</label>
                        <div class="col-sm-8">
                            <select class="form-control" id="kategori" name="id_kategori" required>
                                <option value="<?= $b->id ?>"><?= $b->nama_kategori ?></option>
                                <?php foreach($kategori as $k) : ?>
                                    <option value="<?= $k->id ?>"><?= $k->nama_kategori ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label" for="harga">Harga</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="harga" type="number" placeholder="Masukkan harga" name="harga" required value="<?= $b->harga ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label" for="penerbit">Penerbit</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="penerbit" type="text" placeholder="Masukkan nama penerbit" name="penerbit" required value="<?= $b->penerbit ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label" for="pengarang">Pengarang</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="pengarang" type="text" placeholder="Masukkan nama pengarang" name="pengarang" required value="<?= $b->pengarang ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label" for="tahun">Tahun</label>
                        <div class="col-sm-8">
                            <input class="form-control" id="tahun" type="text" placeholder="Masukkan tahun terbit" name="tahun" required value="<?= $b->tahun ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label" for="deskripsi">Deskripsi</label>
                        <div class="col-sm-12">
                            <textarea name="deskripsi" id="deskripsi" cols="80" rows="5" placeholder="Masukkan deskripsi/sinopsis buku"><?= $b->deskripsi ?></textarea>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary my-3">Simpan Perubahan</button>
                    <a href="<?= base_url() ?>buku" class="btn btn-warning my-3">Kembali</a>
	              </div>
	            </div>
	          </div>
	        </div>
	    </form>
	<?php endforeach; ?>
	</div>
</div>