<!DOCTYPE html>
<html><head>
	<title></title>
</head><body>
	<h2 align="center">Laporan Data Buku</h2>
	<br>
	<br>
	<table cellpadding="6px" border="1 solid black" width="100%">
		<tr>
			<th>No</th>
            <th>Judul</th>
            <th>Penerbit</th>
            <th>Pengarang</th>
            <th>Tahun</th>
            <th>Kategori</th>
            <th>Harga</th>
		</tr>
		<?php $no = 1; ?>
		<?php foreach($buku as $b) : ?>
			<tr>
				<th><?= $no++ ?></th>
                <td><?= $b->judul; ?></td>
                <td><?= $b->penerbit; ?></td>
                <td><?= $b->pengarang; ?></td>
                <td><?= $b->tahun; ?></td>
                <td><?= $b->nama_kategori; ?></td>
                <td>Rp. <?= number_format($b->harga); ?></td>
			</tr>
		<?php endforeach ?>
	</table>
</body></html>