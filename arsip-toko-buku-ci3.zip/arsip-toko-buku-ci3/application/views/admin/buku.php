<div class="body flex-grow-1 px-3">
 <div class="container-lg">
    <div class="row">
    <div class="col-md-12">
        <div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalTambahLabel">Tambah Data</h5>
                <button class="btn-close" type="button" data-coreui-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?= base_url() ?>buku/tambah" method="post" enctype="multipart/form-data">
                    
                    <div class="modal-body">
                        
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="judul">Judul Buku</label>
                            <div class="col-sm-8">
                                <input class="form-control" id="judul" type="text" placeholder="Masukkan judul buku" name="judul" required value="">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="kategori">Kategori</label>
                            <div class="col-sm-8">
                                <select class="form-control" id="kategori" name="id_kategori" required>
                                    <option value="">-- Pilih Kategori --</option>
                                    <?php foreach($kategori as $k) : ?>
                                        <option value="<?= $k->id ?>"><?= $k->nama_kategori ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="harga">Harga</label>
                            <div class="col-sm-8">
                                <input class="form-control" id="harga" type="number" placeholder="Masukkan harga" name="harga" required value="">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="penerbit">Penerbit</label>
                            <div class="col-sm-8">
                                <input class="form-control" id="penerbit" type="text" placeholder="Masukkan nama penerbit" name="penerbit" required value="">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="pengarang">Pengarang</label>
                            <div class="col-sm-8">
                                <input class="form-control" id="pengarang" type="text" placeholder="Masukkan nama pengarang" name="pengarang" required value="">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="tahun">Tahun</label>
                            <div class="col-sm-8">
                                <input class="form-control" id="tahun" type="text" placeholder="Masukkan tahun terbit" name="tahun" required value="">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="deskripsi">Deskripsi</label>
                            <div class="col-sm-12">
                                <textarea name="deskripsi" id="deskripsi" cols="50" rows="5" placeholder="Masukkan deskripsi/sinopsis buku"></textarea>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="gambar">Upload Gambar</label>
                            <div class="col-sm-8">
                                <input class="form-control" id="gambar" type="file" name="gambar" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-coreui-dismiss="modal">Batal</button>
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </div>
                </form>
            </div>
            </div>
        </div>
        <div class="d-flex justify-content-between align-items-center">    
            <button class="btn btn-primary mb-4" type="button" data-coreui-toggle="modal" data-coreui-target="#modalTambah">Tambah Data</button>
            <a href="<?= base_url() ?>buku/pdf" class="btn btn-danger ms-auto mb-4">Export PDF</a>
        </div>
        <div class="card mb-4">
          <div class="card-header">Data Buku</div>
          <div class="card-body">
            <div class="row">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Judul</th>
                        <th scope="col">Penerbit</th>
                        <th scope="col">Pengarang</th>
                        <th scope="col">Tahun</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Aksi</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach($buku as $b) : ?>
                    <tr>
                        <th scope="row"><?= $no++ ?></th>
                        <td><?= $b->judul; ?></td>
                        <td><?= $b->penerbit; ?></td>
                        <td><?= $b->pengarang; ?></td>
                        <td><?= $b->tahun; ?></td>
                        <td><?= $b->nama_kategori; ?></td>
                        <td>Rp. <?= number_format($b->harga); ?></td>
                        <td>
                            <a class="btn btn-primary" href="<?= base_url() ?>buku/detail/<?= $b->id_buku ?>">
                            <svg class="icon">
                                <use xlink:href="<?= base_url() ?>assets/vendors/@coreui/icons/svg/free.svg#cil-magnifying-glass"></use>
                            </svg>
                            </a>
                            <a class="btn btn-warning" href="<?= base_url() ?>buku/edit/<?= $b->id_buku ?>">
                            <svg class="icon">
                                <use xlink:href="<?= base_url() ?>assets/vendors/@coreui/icons/svg/free.svg#cil-pen"></use>
                            </svg>
                            </a>
                            <a class="btn btn-danger" href="<?= base_url() ?>buku/delete/<?= $b->id_buku ?>" onclick="javascript: return confirm('Apakah anda ingin menghapus data ini?')">
                            <svg class="icon">
                                <use xlink:href="<?= base_url() ?>assets/vendors/@coreui/icons/svg/free.svg#cil-trash"></use>
                            </svg>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <!-- /.row-->
              <!-- </div> -->
            </div>
          </div>
        </div>
      </div>
      <!-- /.col-->
    </div>
    <!-- /.row-->