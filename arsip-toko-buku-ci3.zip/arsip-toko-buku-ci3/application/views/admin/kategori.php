<div class="body flex-grow-1 px-3">
 <div class="container-lg">
    <div class="row">
    <div class="col-md-12">
        <div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="modalTambahLabel">Tambah Data</h5>
                <button class="btn-close" type="button" data-coreui-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?= base_url() ?>kategori/tambah" method="post">
                    
                    <div class="modal-body">
                        <div class="mb-3 row">
                            <label class="col-sm-4 col-form-label" for="nama">Nama Kategori</label>
                            <div class="col-sm-8">
                                <input class="form-control" id="nama" type="text" placeholder="Masukkan nama kategori" name="nama_kategori" required value="">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-coreui-dismiss="modal">Batal</button>
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </div>
                </form>
            </div>
            </div>
        </div>
        <button class="btn btn-primary mb-4" type="button" data-coreui-toggle="modal" data-coreui-target="#modalTambah">Tambah Data</button>
        <div class="card mb-4">
          <div class="card-header">Data Kategori</div>
          <div class="card-body">
            <div class="row">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama Kategori</th>
                        <th scope="col">Aksi</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach($kategori as $k) : ?>
                    <tr>
                        <th scope="row"><?= $no++ ?></th>
                        <td><?= $k->nama_kategori; ?></td>
                        <td>
                        <div class="modal fade" id="modalEdit<?= $k->id ?>" tabindex="-1" aria-labelledby="modalEditLabel<?= $k->id ?>" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="modalEditLabel<?= $k->id ?>">Update Data</h5>
                                <button class="btn-close" type="button" data-coreui-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?= base_url() ?>kategori/update" method="post">
                                    <input type="hidden" value="<?= $k->id ?>" name="id">
                                    <div class="modal-body">
                                        <div class="mb-3 row">
                                            <label class="col-sm-4 col-form-label" for="enama">Nama Kategori</label>
                                            <div class="col-sm-8">
                                                <input class="form-control" id="enama" type="text" placeholder="Masukkan nama kategori" name="enama_kategori" required value="<?= $k->nama_kategori ?>">
                                                
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn btn-secondary" type="button" data-coreui-dismiss="modal">Batal</button>
                                        <button class="btn btn-primary" type="submit">Simpan</button>
                                    </div>
                                </form>
                            </div>
                            </div>
                        </div>
                            <button class="btn btn-primary" data-coreui-toggle="modal" data-coreui-target="#modalEdit<?= $k->id ?>">
                            <svg class="icon">
                                <use xlink:href="<?= base_url() ?>assets/vendors/@coreui/icons/svg/free.svg#cil-pen"></use>
                            </svg>
                            </button>
                            <a class="btn btn-danger" href="<?= base_url() ?>/kategori/delete/<?= $k->id ?>" onclick="javascript: return confirm('Apakah anda ingin menghapus data ini?')">
                            <svg class="icon">
                                <use xlink:href="<?= base_url() ?>assets/vendors/@coreui/icons/svg/free.svg#cil-trash"></use>
                            </svg>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <!-- /.row-->
              <!-- </div> -->
            </div>
          </div>
        </div>
      </div>
      <!-- /.col-->
    </div>
    <!-- /.row-->