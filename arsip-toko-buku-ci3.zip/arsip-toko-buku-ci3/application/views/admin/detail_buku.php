<div class="body flex-grow-1 px-3">
	<div class="container-lg">
    <?php foreach($buku as $b) : ?>
		<div class="card p-2">
      <div class="row g-0">
        <div class="col-md-4"><img class="card-img" src="<?= base_url() ?>uploads/<?= $b->gambar ?>" alt="gambar buku" style="max-height: 500px;"></div>
        <div class="col-md-8">
          <div class="card-body">
            <table class="table">
            	<tr>
            		<th>Judul</th>
            		<td><?= $b->judul ?></td>
            	</tr>
            	<tr>
            		<th>Kategori</th>
            		<td><?= $b->nama_kategori ?></td>
            	</tr>
            	<tr>
            		<th>Harga</th>
            		<td><?= $b->harga ?></td>
            	</tr>
            	<tr>
            		<th>Penerbit</th>
            		<td><?= $b->penerbit ?></td>
            	</tr>
            	<tr>
            		<th>Pengarang</th>
            		<td><?= $b->pengarang ?></td>
            	</tr>
            	<tr>
            		<th>Deskripsi</th>
            		<td><?= $b->deskripsi ?></td>
            	</tr>
              <tr>
                <th>Tahun</th>
                <td><?= $b->tahun ?></td>
              </tr>
            </table>
            <a href="<?= base_url() ?>buku" class="btn btn-primary">Kembali</a>
          </div>
        </div>
      </div>
    </div>
<?php endforeach; ?>
	</div>
</div>