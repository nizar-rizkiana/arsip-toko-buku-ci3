<footer class="footer">
        <div>Re-Design By © 2023 Nizar rizkiana</div>
      </footer>
    </div>
    <!-- CoreUI and necessary plugins-->
    <script src="<?php echo base_url(); ?>assets/vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/simplebar/js/simplebar.min.js"></script>
    <!-- Plugins and scripts required by this view-->
    <script src="<?php echo base_url(); ?>assets/vendors/chart.js/js/chart.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/@coreui/chartjs/js/coreui-chartjs.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/@coreui/utils/js/coreui-utils.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
    <script>
    </script>

  </body>
</html>