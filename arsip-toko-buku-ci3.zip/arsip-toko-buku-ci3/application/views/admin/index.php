
      <div class="body flex-grow-1 px-3">
        <div class="container-lg">
          <div class="row">
            <!-- /.col-->
            <div class="col-sm-6 col-lg-4">
              <div class="card mb-4 text-white bg-primary">
                <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                  <div>
                    <div class="fs-4 fw-semibold"><?= $buku ?></div>
                    <div>Buku</div>
                  </div>
                  <svg class="card-icon" style="opacity:0.4;">
                    <use xlink:href="<?= base_url() ?>assets/vendors/@coreui/icons/svg/free.svg#cil-book"></use>
                  </svg>
                </div>
              </div>
            </div>
            <!-- /.col-->
            <!-- /.col-->
            <div class="col-sm-6 col-lg-4">
              <div class="card mb-4 text-white bg-danger">
                <div class="card-body pb-0 d-flex justify-content-between align-items-start">
                  <div>
                    <div class="fs-4 fw-semibold"><?= $kategori ?></div>
                    <div>Kategori</div>
                  </div>
                  <svg class="card-icon" style="opacity:0.4;">
                    <use xlink:href="<?= base_url() ?>assets/vendors/@coreui/icons/svg/free.svg#cil-list"></use>
                  </svg>
                </div>
              </div>
            </div>
            <!-- /.col-->
            <!-- /.col-->
          </div>
          <!-- /.row-->
          <div class="row">
            <div class="col-md-12">
              <div class="card mb-4">
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="row">
                      
                      </div>
                      <!-- /.row-->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.col-->
          </div>
          <!-- /.row-->