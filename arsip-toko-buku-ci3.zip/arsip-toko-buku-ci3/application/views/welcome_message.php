<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Aplikasi Arsip Toko Buku</title>
	<style>
		*{
			padding: 0;
			margin: 0;
			box-sizing: border-box;
		}

		#base-layer{
			height: 100vh;
			width: 100vw;
			background-image: url('<?= base_url() ?>assets/img/bg-home.jpg');
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center;
		}
		.container{
			width: 80%;
			height: 100%;
			padding: 18px;
			background-color: rgba(0, 0, 0, 0.6);
			margin: 0 auto;
			color: white;
			text-align: center;
		}
		.btn{
			padding: 12px;
			height: 16px;
			background-color: blueviolet;
			color: white;
			text-decoration: none;
			border-radius: 8px;
		}
		p{
			font-size: 20px;
		}
	</style>
</head>
<body>
	<div id="base-layer">
		<div class="container">
			<h1>APLIKASI ARSIP TOKO BUKU</h1>
			<br>
			<br>
			<br>
			<p>Aplikasi ini dapat digunakan untuk mencatat dan mengelola koleksi buku dari sebuah toko buku</p>
			<p>Data yang di inputkan meliputi : judul buku, kategori, harga, nama penerbit, nama pengarang, tahun terbit, cover buku</p>
			<br>
			<p>Silahkan login terlebih dahulu untuk mengakses halaman admin</p>
			<br>
			<a href="<?= base_url() ?>auth" class="btn">Login Admin</a>
			<br>
			<br>
			<p>Username : admin</p>
			<p>Password : 1234</p>
		</div>
	</div>
</body>
</html>