<?php

class Buku extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('username'))
		{
			redirect('auth');
		}
	}
	
	public function index()
	{
		$data = [
			'kategori' => $this->M_kategori->tampil_data()->result(),
			'buku' => $this->M_buku->tampil_data()->result()
		];
		$this->load->view('admin/templates/header');
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/templates/navbar');
		$this->load->view('admin/buku', $data);
		$this->load->view('admin/templates/footer');
	}

	public function detail($id)
	{
		$data = [
			'buku' => $this->M_buku->detail_data($id, 'tb_buku')->result()
		];

		$this->load->view('admin/templates/header');
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/templates/navbar');
		$this->load->view('admin/detail_buku', $data);
		$this->load->view('admin/templates/footer');
	}

	public function tambah()
	{
		$gambar = $_FILES['gambar']['name'];
		if ($gambar=''){} else{
            $config ['upload_path'] = './uploads';
            $config ['allowed_types'] = 'jpg|jpeg|png';

            $this->load->library('upload',$config);
            if(!$this->upload->do_upload('gambar')){
                echo "Gambar gagal di Upload!";
                
            }else {
                #echo $this->upload->display_errors();
                $gambar = $this->upload->data('file_name');
            }
        }
		$data = [
			'judul' 		=> $this->input->post('judul'),
			'id_kategori' 	=> $this->input->post('id_kategori'),
			'harga' 		=> $this->input->post('harga'),
			'penerbit'		=> $this->input->post('penerbit'),
			'pengarang' 	=> $this->input->post('pengarang'),
			'tahun' 		=> $this->input->post('tahun'),
			'deskripsi' 	=> $this->input->post('deskripsi'),
			'gambar'		=> $gambar
		];

		$this->M_buku->input_data($data, 'tb_buku');
		redirect('/buku');
	}

	public function edit($id)
	{
		$data = [
			'kategori' => $this->M_kategori->tampil_data()->result(),
			'buku' => $this->M_buku->edit_data($id, 'tb_buku')->result()
		];

		$this->load->view('admin/templates/header');
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/templates/navbar');
		$this->load->view('admin/edit_buku', $data);
		$this->load->view('admin/templates/footer');
	}

	public function update()
	{
		$id = $this->input->post('id');
		$gambarFile = $_FILES['gambar']['name'];
		if ($gambarFile 
			==''){
			$gambar = $this->input->post('gambarLama');
		} else{
            $config ['upload_path'] = './uploads';
            $config ['allowed_types'] = 'jpg|jpeg|png';

            $this->load->library('upload',$config);
            if(!$this->upload->do_upload('gambar')){
                echo "Gambar gagal di Upload!";
                
            }else {
                #echo $this->upload->display_errors();
                $gambar = $this->upload->data('file_name');
            }
        }
		$data = [
			'judul' 		=> $this->input->post('judul'),
			'id_kategori' 	=> $this->input->post('id_kategori'),
			'harga' 		=> $this->input->post('harga'),
			'penerbit'		=> $this->input->post('penerbit'),
			'pengarang' 	=> $this->input->post('pengarang'),
			'tahun' 		=> $this->input->post('tahun'),
			'deskripsi' 	=> $this->input->post('deskripsi'),
			'gambar'		=> $gambar
		];

		$this->M_buku->update_data(['id_buku' => $id], $data, 'tb_buku');
		redirect('/buku');
	}

	public function delete($id)
	{
		$this->M_buku->hapus_data(['id_buku'=> $id], 'tb_buku');
		redirect('/buku');

	}

	public function pdf()
	{
		$this->load->library('dompdf_gen');

		$data = [
			'buku' => $this->M_buku->tampil_data()->result()
		];

		$this->load->view('admin/buku_pdf', $data);

		$paper_size = 'A4';
		$orientation = 'portrait';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("laporan_data_buku.pdf", ['Attachment' => 0]);
	}
}
