<?php

class Auth extends CI_Controller{

    public function index()
    {
        $this->load->view('admin/login');
    }

    public function login(){ 
        $auth = $this->M_auth->cek_login();

        if($auth == FALSE){
            $this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Username atau Password Salah!
          </div>');
            
            redirect('auth');
        } else{
            $this->session->set_userdata('username',$auth->username);
            redirect('dashboard');
        }
    }

    public function logout(){

        $this->session->sess_destroy();
        redirect('auth');
    }

}
