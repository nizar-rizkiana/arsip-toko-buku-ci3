<?php

class Kategori extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('username'))
		{
			redirect('auth');
		}
	}
	
	public function index()
	{
		$data = [
			'kategori' => $this->M_kategori->tampil_data()->result()
		];
		$this->load->view('admin/templates/header');
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/templates/navbar');
		$this->load->view('admin/kategori', $data);
		$this->load->view('admin/templates/footer');
	}

	public function tambah()
	{
		$nama = $this->input->post('nama_kategori');

		$this->M_kategori->input_data(['nama_kategori' => $nama], 'tb_kategori');
		redirect('/kategori');
	}

	public function update()
	{
		$id = $this->input->post('id');
		$data = [
			'nama_kategori' => $this->input->post('enama_kategori')
		];

		$this->M_kategori->update_data(['id' => $id], $data, 'tb_kategori');
		redirect('/kategori');
	}

	public function delete($id)
	{
		$this->M_kategori->hapus_data(['id'=> $id], 'tb_kategori');
		redirect('/kategori');

	}
}
